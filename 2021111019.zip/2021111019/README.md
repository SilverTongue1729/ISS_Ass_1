# ISS Assignment 1

###### 2021111019, Sriteja Reddy Pashya

## Question 1:
The quotes.txt file should be available in the folder
## Question 2:
Run the file as `./q2.sh file.txt`
## Question 3:
Run the file as `./q3.sh file.txt`
## Question 4:
Give comma separted values as input
## Question 5:
Give input in command line
